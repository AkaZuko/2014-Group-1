package spree;

public interface SchedulingInt {

	boolean getSchedule();
	//false if schedule not avaiilable 
}
