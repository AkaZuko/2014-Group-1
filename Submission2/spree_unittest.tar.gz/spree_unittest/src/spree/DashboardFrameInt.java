package spree;

public interface DashboardFrameInt {

	void viewDashboard();
}
