package spree;

public interface ConvenorInt {
 
	 public AccData accdata=null;
	 void viewDepartmentDetails(String DeptName);
	 int viewFinances();
	 
	  
	 
	 
}
