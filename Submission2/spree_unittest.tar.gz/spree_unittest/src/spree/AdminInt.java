package spree;


public interface AdminInt {
	
	boolean validateLogIn(Argument arg, Password pwd);
	
	
}
