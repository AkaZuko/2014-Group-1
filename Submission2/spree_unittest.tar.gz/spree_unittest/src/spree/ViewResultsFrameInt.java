package spree;

public interface ViewResultsFrameInt {

	
	void viewResults();
	
}
