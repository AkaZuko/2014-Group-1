package spree;


public interface LogInInt {
	boolean validateLogIn(Argument arg, Password pwd);
}
