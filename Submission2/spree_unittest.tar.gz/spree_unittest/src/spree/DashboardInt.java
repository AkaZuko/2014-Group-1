package spree;

public interface DashboardInt {
	
	void displayDash();
	
}
