package spree;

public interface AccDataInt {
	void addData();
	void viewData();
	void modifyData();
	void validateData();
	
}
