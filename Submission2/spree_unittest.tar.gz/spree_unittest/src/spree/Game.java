package spree;

public interface Game {

}
