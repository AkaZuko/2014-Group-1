package spree;

public interface SubmitScheduleFrameInt {

	
	void requestSchedule();
	
}
