package spree;

public interface EventRegInt {
	void doEventReg();
}
