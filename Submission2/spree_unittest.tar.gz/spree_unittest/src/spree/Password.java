package spree;

public enum Password {
	P1, P2, P3;
}
