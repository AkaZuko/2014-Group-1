package spree;

public interface UpdateProfileFrameInt {
		void updateProfile();
		
}
