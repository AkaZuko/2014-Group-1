package spree;

public enum Argument {
	ORGANISERLOGIN, EMLOGIN, PARTCIPANTLOGIN;
}
