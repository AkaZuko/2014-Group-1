package spree;

public interface SendMessageFrameInt {

	boolean sendMessage();
	
}
