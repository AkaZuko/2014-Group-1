package spree;

public interface ParticipantProfileFrameInt {
	void participantLogIn();

}
