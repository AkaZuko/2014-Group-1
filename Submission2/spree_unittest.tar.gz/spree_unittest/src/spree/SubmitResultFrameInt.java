package spree;

public interface SubmitResultFrameInt {

}
