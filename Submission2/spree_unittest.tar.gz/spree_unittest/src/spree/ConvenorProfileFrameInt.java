package spree;

public interface ConvenorProfileFrameInt {
	void convenorLogIn();
}
