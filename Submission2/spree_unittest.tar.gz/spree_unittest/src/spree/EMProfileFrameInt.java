package spree;

public interface EMProfileFrameInt {
	void EMLogIn();

}
