package spree;
//import static org.easymock.EasyMock.createNiceMock;
public interface EventsHeadInt {

	String name=null;
	//-1 if fail
	int approveInventoryRequest();
	void viewLog();
	
	
	
	
}



