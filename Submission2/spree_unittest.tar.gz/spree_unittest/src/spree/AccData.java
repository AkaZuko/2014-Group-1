package spree;

public interface AccData {

	Admin admin=null;
	
	void viewDepartmentDetails();
	int  viewFinances();
	
	
}
