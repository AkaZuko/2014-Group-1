package spree;

public interface EventManagerInt {
	String name=null;
	Game game=null;
	
    void viewInventoryRequest();
	boolean setResult();
	void getMessage();
	boolean sendMessage();
	void viewDetails();
}
